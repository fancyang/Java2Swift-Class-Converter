# Java -> Swift2 Object Converter
This is a simple converter for Java Code to Swift3.x Code using regex

Thanks for the original example from Java Class to Swift2.x Class by BetaS

## Convert this -> self, null -> nil
## Function & Parameter Convert
[Origin]
```java
public int func1() {
  blahblahblah
}
```
[Converted]
```swift
func func1() -> Int {
  blahblahblah
}
```
## Constructor Convert
[Origin]
```java
class Test {
  public Test(int foo) {
    blahblahblah
  }
}
```
[Converted]
```swift
class Test {
  init(foo: Int) {
    blahblahblah
  }
}
```
## Variable Decleration Convert
[Origin]
```java
class Test {
  private int foo = 0;
  private String bar;
}
```
[Converted]
```swift
class Test {
  var foo: Int = 0;
  var bar: String = ""; // Auto generated default value as same as Java
}
```

 